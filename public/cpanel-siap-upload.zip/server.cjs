var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_child_process = require("child_process");
var import_vite = require("vite");
var import_genai = require("@google/genai");
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json({ limit: "10mb" }));
  app.all(["/cpanel-siap-upload.zip", "/api/download-zip"], (req, res) => {
    const zipPublic = import_path.default.join(process.cwd(), "public", "cpanel-siap-upload.zip");
    const zipDist = import_path.default.join(process.cwd(), "dist", "cpanel-siap-upload.zip");
    let targetFile = "";
    if (import_fs.default.existsSync(zipPublic) && import_fs.default.statSync(zipPublic).size > 1e5) {
      targetFile = zipPublic;
    } else if (import_fs.default.existsSync(zipDist) && import_fs.default.statSync(zipDist).size > 1e5) {
      targetFile = zipDist;
    }
    if (!targetFile) {
      try {
        console.log("Generating ZIP on demand...");
        (0, import_child_process.execSync)("node scripts/make-zip.js", { stdio: "inherit" });
        if (import_fs.default.existsSync(zipPublic) && import_fs.default.statSync(zipPublic).size > 1e5) targetFile = zipPublic;
        else if (import_fs.default.existsSync(zipDist) && import_fs.default.statSync(zipDist).size > 1e5) targetFile = zipDist;
      } catch (err) {
        console.error("On-demand ZIP generation failed:", err);
      }
    }
    if (targetFile && import_fs.default.existsSync(targetFile)) {
      const stat = import_fs.default.statSync(targetFile);
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Length", stat.size.toString());
      res.setHeader("Content-Disposition", 'attachment; filename="cpanel-siap-upload.zip"');
      res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      return res.sendFile(targetFile);
    }
    return res.status(404).json({ error: "File cpanel-siap-upload.zip tidak ditemukan." });
  });
  app.all("/api.php", (req, res) => {
    const action = req.query.action || req.body?.action || "status";
    if (action === "download_zip") {
      return res.redirect("/cpanel-siap-upload.zip");
    }
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    return res.status(200).json({
      status: "error",
      code: "PREVIEW_ENVIRONMENT",
      is_preview: true,
      php_version: null,
      message: "Anda saat ini membuka aplikasi di Link Preview AI Studio (Node.js/Cloud Run)",
      detail: "Server preview di AI Studio menggunakan Node.js sehingga kode PHP tidak diproses oleh PHP engine cPanel hosting Anda.",
      hint: "Perubahan versi PHP 8.1 / 8.2 yang Anda lakukan di cPanel hanya berlaku di server cPanel Anda. Silakan masukkan URL website cPanel Anda di menu 'Panduan Deploy MySQL' untuk menghubungkan & menguji koneksi langsung ke server cPanel."
    });
  });
  app.use(import_express.default.static(import_path.default.join(process.cwd(), "public")));
  const getGeminiClient = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is missing.");
    }
    return new import_genai.GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
  };
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });
  app.post("/api/ai/diagnose-character", async (req, res) => {
    try {
      const { studentName, startDate, endDate, habitsData, records, teacherName, className, schoolName } = req.body;
      const dataToProcess = habitsData || records || [];
      if (!studentName) {
        return res.status(400).json({ error: "Nama siswa wajib diisi." });
      }
      const ai = getGeminiClient();
      const prompt = `
Anda adalah seorang wali kelas di ${schoolName || "Madrasah Ibtidaiyah"} yang ramah, santun, bijaksana, dan penuh perhatian.
Tugas Anda adalah membuat laporan analisis perkembangan karakter "7 Kebiasaan Anak Indonesia Hebat" yang LENGKAP dan DETAIL untuk disajikan dalam bentuk pesan WhatsApp kepada Orang Tua/Wali Murid dari siswa bernama: ${studentName}.

Detail Informasi:
- Nama Siswa: ${studentName}
- Kelas: ${className || "Kelas 1A"}
- Wali Kelas: ${teacherName || "Guru Pengampu"}
- Periode Pemantauan: ${startDate || "Awal Bulan"} s/d ${endDate || "Akhir Bulan"}

Data Catatan Kebiasaan Harian Siswa selama periode tersebut:
${JSON.stringify(dataToProcess, null, 2)}

7 Kebiasaan Anak Indonesia Hebat yang dipantau meliputi:
1. Bangun Pagi
2. Beribadah (Shalat 5 Waktu)
3. Berolahraga
4. Makan Sehat & Bergizi
5. Gemar Belajar
6. Bermasyarakat
7. Tidur Cepat

INSTRUKSI LAYOUT & KONTEN LAPORAN (SANGAT PENTING):
1. *Judul*: Cukup *LAPORAN ANALISIS DIAGNOSTIK 7 KEBIASAAN ANAK INDONESIA HEBAT* (HAPUS dan JANGAN tampilkan baris nama sekolah/kelas di bawah judul).
2. *Pembuka*: Salam hangat islami, menyapa Orang Tua/Wali Murid ananda ${studentName} dengan ramah.
2. *Kesimpulan Masing-Masing 7 Kebiasaan* (Harus mencakup evaluasi riil untuk setiap kebiasaan di bawah ini, gunakan format *bold* untuk judul kebiasaan):
   - *1. Bangun Pagi*: Berikan kesimpulan kedisiplinan dan keteraturan bangun pagi ananda.
   - *2. Beribadah (Sholat 5 Waktu)*: Berikan kesimpulan kelengkapan dan kekhusyukan ibadah sholat 5 waktu (Subuh, Dhuhur, Ashar, Maghrib, Isya).
   - *3. Berolahraga*: Berikan kesimpulan keaktifan olah tubuh dan kebugaran fisik ananda.
   - *4. Makan Sehat & Bergizi*: Berikan kesimpulan kebiasaan makan makanan bergizi (pagi, siang, malam).
   - *5. Gemar Belajar*: Berikan kesimpulan semangat belajar mandiri, membaca, dan penyelesaian tugas.
   - *6. Bermasyarakat*: Berikan kesimpulan interaksi sosial, kebaikan, dan kepedulian terhadap lingkungan/teman.
   - *7. Tidur Cepat*: Berikan kesimpulan keteraturan jam tidur malam yang cukup dan tepat waktu.
3. *Rekomendasi & Saran untuk Orang Tua*:
   - Tuliskan 3-4 rekomendasi/saran konkret dan praktis yang dapat dilakukan Bapak/Ibu di rumah untuk mempertahankan atau meningkatkan kebiasaan baik ananda.
4. *Penutup*: Ungkapan apresiasi atas kerjasama orang tua, doa kebaikan untuk ananda dan keluarga, serta salam penutup.

Format teks disesuaikan dengan gaya pesan WhatsApp (gunakan penekanan *teks tebal* pada poin penting agar rapi dan mudah dibaca).`;
      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          temperature: 0.7
        }
      });
      const reportText = response.text || "Gagal menghasilkan laporan diagnostik.";
      return res.json({ success: true, report: reportText });
    } catch (err) {
      console.warn("Gemini API not available or failed, returning calculated report:", err.message);
      const { studentName, startDate, endDate, className, teacherName, schoolName, habitsData, records } = req.body;
      const recs = habitsData || records || [];
      const dateList = [];
      if (startDate && endDate) {
        let curr = new Date(startDate);
        const last = new Date(endDate);
        if (!isNaN(curr.getTime()) && !isNaN(last.getTime()) && curr <= last) {
          while (curr <= last) {
            dateList.push(curr.toISOString().split("T")[0]);
            curr.setDate(curr.getDate() + 1);
          }
        }
      }
      const totalDays = Math.max(dateList.length, recs.length, 1);
      const wakeUpCount = recs.filter((r) => r.wakeUpEarly).length;
      let totalPrayers = 0;
      recs.forEach((r) => {
        if (r.prayers) {
          if (r.prayers.subuh) totalPrayers++;
          if (r.prayers.dhuhur) totalPrayers++;
          if (r.prayers.ashar) totalPrayers++;
          if (r.prayers.maghrib) totalPrayers++;
          if (r.prayers.isya) totalPrayers++;
        }
      });
      const prayerPct = Math.round(totalPrayers / (totalDays * 5) * 100);
      const exerciseCount = recs.filter((r) => r.exercise).length;
      let totalMeals = 0;
      recs.forEach((r) => {
        if (r.healthyMeals) {
          if (r.healthyMeals.pagi) totalMeals++;
          if (r.healthyMeals.siang) totalMeals++;
          if (r.healthyMeals.malam) totalMeals++;
        }
      });
      const mealsPct = Math.round(totalMeals / (totalDays * 3) * 100);
      const learnCount = recs.filter((r) => r.loveLearning).length;
      const socialCount = recs.filter((r) => r.socializing).length;
      const sleepCount = recs.filter((r) => r.sleepEarly).length;
      const wakeUpPct = Math.round(wakeUpCount / totalDays * 100);
      const exercisePct = Math.round(exerciseCount / totalDays * 100);
      const learnPct = Math.round(learnCount / totalDays * 100);
      const socialPct = Math.round(socialCount / totalDays * 100);
      const sleepPct = Math.round(sleepCount / totalDays * 100);
      const reportText = `*LAPORAN ANALISIS DIAGNOSTIK 7 KEBIASAAN ANAK INDONESIA HEBAT*

Assalamu'alaikum Wr. Wb.
Bapak/Ibu/Wali Murid dari ananda *${studentName || "Siswa"}*,

Berikut hasil evaluasi diagnostik & analisis perkembangan *7 Kebiasaan Anak Indonesia Hebat* ananda periode *${startDate || "Awal Bulan"} s/d ${endDate || "Akhir Bulan"}* (${totalDays} Hari Pemantauan):

\u{1F4CC} *KESIMPULAN EVALUASI PER KEBIASAAN:*

*1. Bangun Pagi (${wakeUpPct}%)*
${wakeUpPct >= 80 ? "Ananda sangat konsisten dan disiplin bangun pagi sebelum Subuh dengan kondisi segar dan bersemangat." : "Ananda sudah menunjukkan kemajuan bangun pagi, mohon terus didampingi keteraturannya terutama di hari libur."}

*2. Beribadah / Sholat 5 Waktu (${prayerPct}%)*
${prayerPct >= 80 ? "Alhamdulillah, pelaksanaan ibadah sholat 5 waktu (Subuh, Dhuhur, Ashar, Maghrib, Isya) tergolong sangat tertib dan rajin." : "Pelaksanaan sholat 5 waktu cukup teratur. Perlu dorongan santun terutama untuk kebiasaan sholat Subuh dan Isya."}

*3. Berolahraga (${exercisePct}%)*
${exercisePct >= 75 ? "Ananda aktif bergerak dan rutin berolahraga untuk menjaga kebugaran jasmani." : "Ananda disarankan untuk diajak aktif berolahraga ringan atau olah tubuh minimal 15-30 menit sehari."}

*4. Makan Sehat & Bergizi (${mealsPct}%)*
${mealsPct >= 80 ? "Pola makan ananda terpantau teratur (Pagi, Siang, Malam) dengan gizi yang baik dan seimbang." : "Pola makan cukup teratur, mohon ditingkatkan konsumsi sayur, buah, serta air putih di rumah."}

*5. Gemar Belajar (${learnPct}%)*
${learnPct >= 80 ? "Ananda memiliki motivasi belajar yang tinggi, rajin membaca, dan disiplin mengerjakan tugas sekolah." : "Ananda sudah mau belajar, disarankan membuat jadwal belajar yang rutin dan bebas dari gangguan media."}

*6. Bermasyarakat (${socialPct}%)*
${socialPct >= 80 ? "Sangat ramah, santun, peduli kepada teman, dan memiliki jiwa kepedulian sosial yang amat baik." : "Sikap sosial ananda baik, terus latih sikap berbagi, empati, dan tolong-menolong di lingkungan rumah."}

*7. Tidur Cepat (${sleepPct}%)*
${sleepPct >= 80 ? "Disiplin mengakhiri aktivitas malam dan tidur tepat waktu sehingga kesegaran fisik selalu terjaga." : "Jam tidur malam ananda terkadang masih larut. Mohon batasi penggunaan HP/TV setelah pukul 20.00 WIB."}

\u{1F4A1} *REKOMENDASI & SARAN KEBIASAAN UNTUK ORANG TUA:*
1. *Apresiasi Berkelanjutan*: Berikan pujian hangat atau *reward* imaterial setiap kali ananda berhasil menjalankan kebiasaan baik secara mandiri.
2. *Keteladanan Ibadah & Pembiasaan*: Ajak ananda sholat berjamaah serta membaca Al-Qur'an/buku bersama untuk membangun karakter religius & gemar membaca.
3. *Manajemen Screen-Time*: Terapkan aturan pembatasan gawai (HP) dan televisi maksimal pukul 20.00 agar waktu istirahat malam ananda optimal.
4. *Komunikasi Efektif*: Buat sesi bincang santai 10 menit sebelum tidur untuk mendengarkan cerita dan perasaan ananda sepanjang hari.

Terima kasih banyak atas partisipasi aktif, bimbingan, dan kerjasama luar biasa Bapak/Ibu di rumah demi tumbuh kembang terbaik ananda.

Wassalamu'alaikum Wr. Wb.
*Wali Kelas ${className || "1A"}*
_${teacherName || "Guru Pengampu"}_`;
      return res.json({
        success: true,
        fallback: true,
        report: reportText
      });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server KAGUM running on http://localhost:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
